package zhkb17_lab3;

import java.util.List;
import javax.sql.DataSource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

public class ElectricStovesDAO implements IElectricStovesDAO {

    private DataSource dataSource;

    @Override
    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public void insert(ElectricStoves customer) { // Реализация вставки новой записи

        JdbcTemplate insert = new JdbcTemplate(dataSource);
        insert.update("INSERT INTO electric_stoves (brand, model) VALUES(?,?)",
                new Object[]{customer.getBrand(), customer.getModel()});
    }

    @Override
    public void append(String brand, String model) {  // Реализация добавления новой записи
        JdbcTemplate insert = new JdbcTemplate(dataSource);
        insert.update("INSERT INTO electric_stoves (brand, model) VALUES(?,?)", new Object[]{brand, model});
    }

    @Override
    public void deleteByBrand(String brand) {  // Реализация удаления записей по бренду
        JdbcTemplate insert = new JdbcTemplate(dataSource);
        insert.update("DELETE FROM electric_stoves WHERE brand LIKE ?", new Object[]{'%' + brand + '%'});
    }

    @Override
    public void delete(final String brand, final String model) {  // Реализация удаления записей с указанными брендом и механизмом
        TransactionTemplate transactionTemplate = new TransactionTemplate(new DataSourceTransactionManager(dataSource));

        transactionTemplate.execute(new TransactionCallback() {
            @Override
            public Object doInTransaction(TransactionStatus status) {

                try {
                    JdbcTemplate delete = new JdbcTemplate(dataSource);
                    delete.update("DELETE FROM electric_stoves WHERE brand = ? AND model = ?", new Object[]{brand, model});
                } catch (RuntimeException e) {
                    status.setRollbackOnly();
                    throw e;
                } catch (Exception e) {
                    status.setRollbackOnly();
                    throw new RuntimeException(e);
                }
                return null;
            }
        });
    }

    @Override
    public void deleteAll() {  // Реализация удаления всех запией
        JdbcTemplate delete = new JdbcTemplate(dataSource);
        delete.update("DELETE FROM electric_stoves");
    }

    @Override
    public void update(String newModel, String oldModel) {  // Изменение записей в таблице
        JdbcTemplate update = new JdbcTemplate(dataSource);
        update.update("UPDATE electric_stoves SET model = ? WHERE model = ?", new Object[]{newModel, oldModel});
    }

    @Override
    public List<ElectricStoves> findByBrand(String brand) {  // Реализация поиска записей по бренду
        JdbcTemplate select = new JdbcTemplate(dataSource);
        String sql = "SELECT * FROM electric_stoves WHERE brand LIKE ?";
        List<ElectricStoves> electricStoves = select.query(sql, new Object[]{'%' + brand + '%'}, new ElectricStovesRowMapper());
        return electricStoves;
    }

    @Override
    public List<ElectricStoves> select(String brand, String model) {  // Реализация получения записей с заданными брендом и механизмом
        JdbcTemplate select = new JdbcTemplate(dataSource);
        return select.query("SELECT  * FROM electric_stoves WHERE brand = ? AND model= ?",
                new Object[]{brand, model}, new ElectricStovesRowMapper());
    }

    @Override
    public List<ElectricStoves> selectAll() {  // Реализация получения всех записей
        JdbcTemplate select = new JdbcTemplate(dataSource);
        return select.query("SELECT * FROM electric_stoves", new ElectricStovesRowMapper());
    }
    
    @Override
    public void appendOnlyBrand(String brand) {  // Реализация добавления новой записи
        JdbcTemplate insert = new JdbcTemplate(dataSource);
        insert.update("INSERT INTO electric_stoves (brand, model) VALUES(?,?)", new Object[]{brand, "????"});
    }
    
    @Override
    public void deleteByModel(String model) {  // Реализация удаления записей по бренду
        JdbcTemplate insert = new JdbcTemplate(dataSource);
        insert.update("DELETE FROM electric_stoves WHERE model LIKE ?", new Object[]{'%' + model + '%'});
    }
    
    @Override
    public void updateBrand(String newBrand, String oldBrand) {  // Изменение записей в таблице
        JdbcTemplate update = new JdbcTemplate(dataSource);
        update.update("UPDATE electric_stoves SET brand = ? WHERE brand = ?", new Object[]{newBrand, oldBrand});
    }
    
    @Override
    public List<ElectricStoves> findByModel(String model) {  // Реализация поиска записей по бренду
        JdbcTemplate select = new JdbcTemplate(dataSource);
        String sql = "SELECT * FROM electric_stoves WHERE model LIKE ?";
        List<ElectricStoves> electricStoves = select.query(sql, new Object[]{'%' + model + '%'}, new ElectricStovesRowMapper());
        return electricStoves;
    }
    
    @Override
    public List<ElectricStoves> selectByBrand(String brand) {  // Реализация получения записей с заданными брендом и механизмом
        JdbcTemplate select = new JdbcTemplate(dataSource);
        return select.query("SELECT  * FROM electric_stoves WHERE brand = ?",
                new Object[]{brand}, new ElectricStovesRowMapper());
    }
    
    @Override
    public List<ElectricStoves> selectByModel(String model) {  // Реализация получения записей с заданными брендом и механизмом
        JdbcTemplate select = new JdbcTemplate(dataSource);
        return select.query("SELECT  * FROM electric_stoves WHERE model = ?",
                new Object[]{model}, new ElectricStovesRowMapper());
    }
}
