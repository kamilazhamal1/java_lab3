package zhkb17_lab3;

import java.util.List;
import javax.sql.DataSource;

public interface IElectricStovesDAO {
    void setDataSource(DataSource ds);                          
    void insert(ElectricStoves customer);                                
    void append(String Brand, String Model);
    void appendOnlyBrand(String Brand);
    void deleteByBrand(String Brand);    
    void deleteByModel(String Model);
    void delete(String Brand, String Model);                 
    void deleteAll();                                           
    void update(String newModel, String oldModel);
    void updateBrand(String newBrand, String oldBrand);
    List<ElectricStoves> findByBrand(String Brand);
    List<ElectricStoves> findByModel(String Model);
    List<ElectricStoves> select(String Brand, String Model);
    List<ElectricStoves> selectByBrand(String Brand);
    List<ElectricStoves> selectByModel(String Model);
    List<ElectricStoves> selectAll();
}
