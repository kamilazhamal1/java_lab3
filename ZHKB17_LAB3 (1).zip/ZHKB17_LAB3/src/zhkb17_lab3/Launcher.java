package zhkb17_lab3;

import java.util.List;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Launcher {

    public static void main(String[] args) {
        try {
            ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml"); // Загрузка файла с биновами

            ElectricStovesDAO electricStovesDAO = (ElectricStovesDAO) context.getBean("customerDAO");

            electricStovesDAO.deleteAll();
            
            ElectricStoves electricStove = new ElectricStoves("ARG", "CE50W01");
            electricStovesDAO.insert(electricStove);

            electricStovesDAO.insert(new ElectricStoves("Artel", "APETITO 01-E"));
            electricStovesDAO.insert(new ElectricStoves("Shivaki", "Ottima 50 G"));
            electricStovesDAO.insert(new ElectricStoves("Midea", "FSC-900BX"));

            System.out.println("Начальная БД:");
            List<ElectricStoves> list = electricStovesDAO.selectAll();
            for (ElectricStoves myElectricStoves : list) {
                System.out.println(myElectricStoves.getBrand()+ " " + myElectricStoves.getModel());
            }
            System.out.println();
            
            electricStovesDAO.deleteByBrand("rte");
            electricStovesDAO.deleteByModel("ttima");
            electricStovesDAO.delete("Midea", "FSC-900BX");

            
            
            System.out.println("Поиск по фрагменту бренда - RG");
            List<ElectricStoves> electricStoves_list = electricStovesDAO.findByBrand("RG");
            if (electricStoves_list != null) {
                for (Object element : electricStoves_list) {
                    System.out.println(element);
                }
            } else {
                System.out.println("Нет данных");
            }
            System.out.println();
            
            electricStovesDAO.append("Bosch", "zcxbHXA060B21Q");
            electricStovesDAO.append("Haasddnsa", "FCCW 680009");
            electricStovesDAO.append("Artel", "APETITO 03-E");
            electricStovesDAO.appendOnlyBrand("&Brand&");
            
            System.out.println("БД перед изменениями:");
            list = electricStovesDAO.selectAll();
            for (ElectricStoves myElectricStoves : list) {
                System.out.println(myElectricStoves.getBrand()+ " " + myElectricStoves.getModel());
            }
            System.out.println();

            electricStovesDAO.update("HXA060B21Q", "zcxbHXA060B21Q");
            electricStovesDAO.updateBrand("Hansa", "Haasddnsa");

            System.out.println("БД после изменений:");
            list = electricStovesDAO.selectAll();
            for (ElectricStoves myElectricStoves : list) {
                System.out.println(myElectricStoves.getBrand() + " " + myElectricStoves.getModel());
            }
            System.out.println();
            
            System.out.println("Поиск по фрагменту модели - 80009");
            electricStoves_list = electricStovesDAO.findByModel("80009");
            if (electricStoves_list != null) {
                for (Object element : electricStoves_list) {
                    System.out.println(element);
                }
            } else {
                System.out.println("Нет данных");
            }
            System.out.println();

            System.out.println("Вывод записей с брендом Artel и моделью APETITO 03-E:");

            list = electricStovesDAO.select("Artel", "APETITO 03-E");
            for (ElectricStoves myElectricStoves : list) {
                System.out.println(myElectricStoves.getBrand() + " " + myElectricStoves.getModel());
            }
            
            System.out.println("Вывод записей с брендом Bosch:");

            list = electricStovesDAO.selectByBrand("Bosch");
            for (ElectricStoves myElectricStoves : list) {
                System.out.println(myElectricStoves.getBrand() + " " + myElectricStoves.getModel());
            }
            
            System.out.println("Вывод записей с моделью FCCW 680009:");

            list = electricStovesDAO.selectByModel("FCCW 680009");
            for (ElectricStoves myElectricStoves : list) {
                System.out.println(myElectricStoves.getBrand() + " " + myElectricStoves.getModel());
            }

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error!");
        }
    }
    
}
